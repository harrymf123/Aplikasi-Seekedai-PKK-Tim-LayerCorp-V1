const Sequelize = require("sequelize");
const db = require("./sequelize");
module.exports = db.sequelize.define(
  "pket_warung",
  {
    id_katering: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUID,
        primaryKey: true
    },
    id_pemesan:{
        type:Sequelize.INTEGER
    },
    id_warung: {
        type: Sequelize.INTEGER
    },
    nama_penerima :{
      type:Sequelize.STRING
    },
    alamat_penerima :{
      type:Sequelize.STRING
    },
    waktu_ambil:{
      type:Sequelize.TEXT
    },
    makanan:{
        type:Sequelize.TEXT
    },          
    harga:{
      type:Sequelize.STRING
    },
    status:{
      type:Sequelize.INTEGER
    }
  },
  { timestamps: false }
);
