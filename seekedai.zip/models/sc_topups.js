const Sequelize = require("sequelize");
const db = require("./sequelize");
module.exports = db.sequelize.define(
  "topup",
  {
    id_tp: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUID,
        primaryKey: true
    },
    fotone:{
        type:Sequelize.STRING
    },
    id_user: {
        type: Sequelize.INTEGER
    } ,
    jumlah : {type:Sequelize.TEXT},
    status :{type:Sequelize.INTEGER}
  },
  { timestamps: false }
);
