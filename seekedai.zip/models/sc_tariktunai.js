const Sequelize = require("sequelize");
const db = require("./sequelize");
module.exports = db.sequelize.define(
  "tarik",
  {
    id_tr: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUID,
        primaryKey: true
    },
    rekening :{type:Sequelize.STRING},
    jumlah:{
        type:Sequelize.TEXT
    },
    id_user: {
        type: Sequelize.INTEGER
    },
    status :{
        type:Sequelize.INTEGER
    }
  },
  { timestamps: false }
);
