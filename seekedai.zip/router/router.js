const   jwt   = require('jsonwebtoken'),
        multer = require('multer'),
        auth  = require('../controller/auth'),
        pesan  = require('../controller/pesan'),
        warung = require("../controller/warung")
        index = require('../controller/index')
function jwt_token(req, res, next) {
  const tokens = req.cookies.ajI2YW52QXM3;  
  if (!tokens) return res.status(401).redirect("/");
    jwt.verify(tokens, "%SESSION_ANONYMOUS%", (err, decoded) => {
      if(err){res.redirect('/login')}
      else{
        req.decoded = decoded
        req.tokenku = tokens
        next()
      }
  });
}
module.exports = app => {
//###################################################################GET
//#######################################################################

app.get("/",                                auth.masuk)
app.get("/register",                        auth.register)
app.get("/admin",                           index.admin)
app.get('/search/',                         index.cari)
app.get('/admine/:key',                     index.settingadmin)
app.get('/search_warung/',                  jwt_token,index.cari_warung)
app.get('/semua_menu',                      index.semua_menu)
app.get('/logout',                          auth.logout)
app.get('/lihat/:id',                       index.lihatWarung)

app.get('/scancode',                        jwt_token,warung.scancode)
app.get('/warung',                          jwt_token,warung.warung)
app.get('/hapusWarung',                     jwt_token,warung.hapusWarung)
app.get('/set/:info',                       jwt_token,warung.setLibur)
app.get('/Adminmenu',                       jwt_token,warung.menuWarung)
app.get('/Adminmenu/hapus/:id',             jwt_token,warung.hapusMenu)
app.get('/rate/bintang/:bintang/:id',       jwt_token,warung.rate)

app.get('/profile',                         jwt_token,index.profile)
app.get('/beranda',                         jwt_token,index.beranda)
app.get('/Adminkatering',                   jwt_token,index.katering)
app.get('/Admintempat',                     jwt_token,index.tempat)
app.get('/hapusTempat/:_qwe',               jwt_token,index.hapusTmpt)
app.get('/katering/:_id',                   jwt_token,index.cekKater)
app.get('/tempat/:_id',                     jwt_token,index.cekTempat)
app.get('/disewaTrue/:_id',                 jwt_token,index.mejaaktif)
app.get('/disewaFalse/:_id',                jwt_token,index.mejanonak)

app.get('/done/:key',                       jwt_token,pesan.done)
app.get('/hapuskater/:key',                 jwt_token,pesan.hapusKater)
app.get('/pesan/:_mejane/:_wr',             jwt_token,pesan.pesanT)
app.get('/nextPesan/:_mejane/:_wr',         jwt_token,pesan.nextPesanT)
app.get('/pembayaran/:tokencash',           jwt_token,pesan.pembayaran)
app.get('/confirm/tempat/:_as',             jwt_token,pesan.konfirT)
app.get('/riwayat',                         jwt_token,pesan.history)


//##################################################################POST
//######################################################################
app.post('/login',                          auth.postlogin)
app.post('/daftar',                         auth.postregis)
app.post('/topup',                          jwt_token,index.topup)
app.post('/tarik',                          jwt_token,index.tariktunai)
app.post('/set_alamat',                     jwt_token,index.set_alamat)
app.post('/addWarung',                      jwt_token,index.addWarung)
app.post('/addMenu',                        jwt_token,index.addMenu)
app.post('/addMeja',                        jwt_token,index.addMeja)
app.post('/StatustempatAktif',              jwt_token,index.ubahSTa)
app.post('/StatustempatNon',                jwt_token,index.ubahSTn)
app.post('/StatuskaterAktif',               jwt_token,index.ubahSKa)
app.post('/StatuskaterNon',                 jwt_token,index.ubahSKn)
app.post('/tambahKater/:_info/:_id',        jwt_token,index.tambahKater)

app.post('/editMenu/',                      jwt_token,warung.editMenu)
app.post('/edit1Warung/',                   jwt_token,warung.edit1Warung)
app.post('/edit2Warung/',                   jwt_token,warung.edit2Warung)

app.post('/bayar/:id',                      jwt_token,pesan.bayar)
}