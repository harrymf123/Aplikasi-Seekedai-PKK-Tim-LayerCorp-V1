const   jwt     =   require('jsonwebtoken'),
        url     =   require('url'),
        waktu   =   require('date-and-time'),    
        Bintangs=   require('star-ratings'),
        qrm     =   require('qr-image'),
        fs      =   require('fs'),
        forD    =   new Date(),
        hari    =   waktu.format(forD,'dddd')
        jam     =   waktu.format(forD, 'HH:mm'),
        users   =   require('../models/sc_auth'),
        warung  =   require("../models/sc_warung"),
        info    =   require("../models/sc_infoWarung"),
        meja    =   require("../models/sc_pesanMeja"),
        katr    =   require("../models/sc_pesanKat"),
        fileQR  =   require("../models/sc_qr"),
        tarik   =   require("../models/sc_tariktunai"),
        topup   =   require("../models/sc_topups"),
        menu    =   require("../models/sc_menuWarung"),        
        conn    =   require('../models/sc_database'),        
    idInfo_acak =   Math.floor(Math.random() * Math.floor(999999)),    
    idMenu_acak =   Math.floor(Math.random() * Math.floor(999999)),
    idMeja_acak =   Math.floor(Math.random() * Math.floor(999999)),
    idKatr_acak =   Math.floor(Math.random() * Math.floor(999999))

//############################################################################################ GET
//#################################################################################################
exports.beranda=(req,res)=>{      
  users.findOne({where:{id_user : req.decoded.idUser}})
    .then(user=>{                  
        var sql = "SELECT * FROM warungs INNER JOIN info_warungs ON warungs.infoWarung = info_warungs.id_warung"
        conn.db.query(sql,(err,ok)=>{
          warung.findAndCountAll({}).then(Jwarong=>{            
          menu.findAndCountAll({}).then(Jmenu=>{                      
            res.render('welcome',{data:user,warong:ok, dataKeywords: 0 , Jw : Jwarong.count , Jm : Jmenu.count})           
          })
          })
        })        
  })      
}
exports.cari_warung=(req,res)=>{    
  var q = url.parse(req.url, true);
  if(q.pathname == "/search_warung/" && req.method === "GET"){ 
    users.findOne({where:{id_user : req.decoded.idUser}})
      .then(user=>{        
        var keyword = q.query.keyword;        
        var sql = "SELECT * FROM warungs WHERE nama_warung LIKE '%"+ keyword +"%'"
        conn.db.query(sql,(err,allwarung)=>{  
        info.findAll().then(infoWarung => {                    
          res.render('all_warungs',{data:user, warong:allwarung,info:infoWarung, dataKeywords: keyword}) 
        })       
      })
    })      
    // var keyword = q.query.keyword;        
    // var sql = "SELECT * FROM warungs WHERE nama_menu LIKE '%"+ keyword +"%'"
    // conn.db.query(sql,(err,hasil)=>{
    //   warung.findAll().then(allwarung=>{
    //     res.render('welcome',{data:user,warong:allwarung,info:infoWarung}) 
    //   })
    // })
  }
}

exports.profile=(req,res)=>{
  users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{
    res.render('profile',{data : wong})
  })
}
exports.set_alamat=(req,res)=>{
  users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{
    users.update({alamat_kater : req.body.alamatkater},{where:{id_user : wong.id_user}}).then(done=>{
      res.redirect('/profile')
    })
  })
}

exports.lihatWarung=(req,res)=>{  
  const idWarung = req.params.id  
  warung.findOne({where:{infoWarung : idWarung}}).then(warong=>{         
    if(warong){      
      info.findOne({id_warung : warong.infoWarung}).then(infoWARUNG=>{
        var votes = [infoWARUNG.b1,infoWARUNG.b2,infoWARUNG.b3,infoWARUNG.b4,infoWARUNG.b5];  
        var datane = {rate_b : Bintangs(votes),total_b:(infoWARUNG.b1+infoWARUNG.b2+infoWARUNG.b3+infoWARUNG.b4+infoWARUNG.b5)+" Orang Menilai"}        
        info.update(datane,{where:{id_warung : warong.infoWarung}}).then(updateINFO=>{
              
          const asd = warong.menuWarung       
          var sql= "SELECT warungs.id_warung , warungs.nama_warung , warungs.infoWarung , warungs.deskripsi , warungs.menuWarung , id_infoWarung , jamBuka , jamTutup , total_b , rate_b , hp , S_tempat , S_katering , lokasi FROM warungs"
          +" INNER JOIN info_warungs ON warungs.infoWarung = info_warungs.id_warung WHERE infoWarung = ? "                        
          conn.db.query(sql,idWarung,(err,hasil)=>{  
                
          var dino = hari.toLowerCase()                                
          var tes1 = jam.split(":")[0]
          var tes2 = jam.split(":")[1]            
          var waktusaiki = tes1+','+tes2      

          var jamBuka = hasil[0].jamBuka      
          var jamTutup = hasil[0].jamTutup
          var ver1 = jamBuka.split(":")[0] , ver2 = jamBuka.split(":")[1]
          var ver3 = jamTutup.split(":")[0] , ver4 = jamTutup.split(":")[1]
          //done
          var jbk = ver1+','+ver2      
          var jtp = ver3+','+ver4          
                            
          menu.findAll({where:{id_warung : asd}}).then(ok=>{               
                  // if('friday' == dino){
                  //   warung.update({bukatutup : 0},{where : {infoWarung : idWarung}}).then(updateTutup=>{
                  //     res.render('page_lihatW',{
                  //       data : hasil[0], status:'Tutup' ,   ko:ok         })         
                  //     })
                  // }        
            if(warong.set_bukatutup == 1){          
              if(waktusaiki >= jbk && waktusaiki < jtp){   
                  warung.update({bukatutup : 1},{where : {infoWarung : idWarung}}).then(updateBuka=>{
                  res.render('lihat_warung',{data : hasil[0], status:'Buka' ,     ko:ok   })          
                })      
              }        
              else{
                  warung.update({bukatutup : 0},{where : {infoWarung : idWarung}}).then(updateTutup=>{
                  res.render('lihat_warung',{
                  data : hasil[0], status:'Tutup' ,   ko:ok         })         
                })
              }                                       
            }else{
              res.render('lihat_warung',{
              data : hasil[0], status:'Libur' ,   ko:ok         })                   
            }        
          })
        }) 
      })  
    })
  }
  else{
    req.session.message = {
      type: 'danger',
      intro: 'ERROR !',
      message: 'Terjadi Kesalahan'
    } 
    res.redirect('/')
  }
  })
  
}





exports.cari=(req,res)=>{
  var q = url.parse(req.url, true);
  if(q.pathname == "/search/" && req.method === "GET"){    
    var keyword = q.query.keyword;        
    var sql = "SELECT * FROM menu_warungs WHERE nama_menu LIKE '%"+ keyword +"%'"
    conn.db.query(sql,(err,hasil)=>{
      warung.findAll().then(allwarung=>{
        res.render('page_search',{dataCari : hasil, dataWarungs: allwarung, dataKeywords: keyword})
      })
    })
  }
}
exports.semua_menu=(req,res)=>{
  var sql = "SELECT * FROM menu_warungs"
  conn.db.query(sql,(err,hasil)=>{
    warung.findAll().then(allwarung=>{
      res.render('page_search',{dataCari : hasil, dataWarungs: allwarung, dataKeywords: 0})
    })
  })
}
exports.katering=(req,res)=>{
  users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{
    warung.findOne({where:{id_pemilik : wong.id_user}}).then(warong=>{            
      katr.findAll({where:{id_warung : warong.id_warung , status : 1}}).then(cekKatering=>{        
        if(cekKatering == 0){          
          res.render('page_katerW',{data : 0})
        }else{
          console.log(cekKatering[0].makanan);
          res.render('page_katerW',{data : cekKatering})
        }
      })      
    })
  })
}

exports.cekKater=(req,res)=>{
  var id = req.params._id
  warung.findOne({where:{infoWarung : id}}).then(warong=>{
    if(warong){      
      menu.findAll({where:{id_warung : warong.menuWarung}}).then(menune=>{        
        if(menune){
          katr.findOne({where:{id_pemesan : req.decoded.idUser , id_warung : warong.id_warung , status :0}}).then(wong=>{
            if(wong){
            var s = wong.makanan ; var data_m = s.split(",")[0] ; var data_t = s.split(",")[1]
            //--------------------------------------------------------------------------------
            var makanan = data_m.split("m: ")[1]
            var total   = data_t.split("t: ")[1]                            
            res.render('katering_menu',{data : menune , dataTotal : 1 , data1 : wong , makanan : makanan , total : total , wr : warong})
            }else{
              res.render('katering_menu',{data : menune , dataTotal : 0})
            }
          })
        }else{
          res.render('',{data : 0})
        }
      })
    }else{
      req.session.message = {
        type: 'danger',
        intro: 'ERROR !',
        message: 'Terjadi Kesalahan'
      } 
      res.redirect('/beranda')
    }
  })
}

exports.tempat=(req,res)=>{
  users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{
    warung.findOne({where:{id_pemilik : wong.id_user}}).then(warong=>{      
      meja.findAll({where:{id_warung : warong.mejaWarung}}).then(tempate=>{    

        if(tempate){          
          res.render('page_tempatW',{data:tempate})
        }else{          
          res.render('page_tempatW',{data:0})
        }
      })
    })
  })
}

exports.hapusTmpt=(req,res)=>{
  const ids = req.params._qwe
  users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{
    warung.findOne({where:{id_pemilik:wong.id_user}}).then(warong=>{
      meja.destroy({where :{nomer_meja : ids , id_warung : warong.mejaWarung}}).then(cekTempat=>{
        if(cekTempat){
          req.session.message = {
            type: 'success',
            intro: 'Berhasil ',
            message: 'Meja Sudah dihapus'
          }  
          res.redirect('/Admintempat')   
        }else{
          req.session.message = {
            type: 'danger',
            intro: 'ERROR !',
            message: 'Terjadi Kesalahan'
          }  
          res.redirect('/Admintempat')   
        }
      })
    })
  })
}

exports.mejaaktif=(req,res)=>{          // KONDISI MEJO ne == DISEWA kate diubah ng TIDAK DISEWA
  const nomer_meja = req.params._id
  users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{
    warung.findOne({where:{id_pemilik:wong.id_user}}).then(warong=>{  
      meja.findOne({where:{nomer_meja : nomer_meja , id_warung : warong.mejaWarung}}).then(tes=>{
        if(tes){
          meja.update({id_pemesan : 0 , nama_pemesan : '-'},{where:{id_pesan : tes.id_pesan}}).then(ok=>{
            req.session.message = {
              type: 'success',
              intro: 'Berhasil ',
              message: 'Status Meja Sudah berubah'
            }  
            res.redirect('/Admintempat') 
          })
        }else{
          req.session.message = {
            type: 'danger',
            intro: 'ERROR !',
            message: 'Terjadi Kesalahan'
          }  
          res.redirect('/Admintempat')   
        }
      })      
    })
  })
} 
exports.mejanonak=(req,res)=>{            //KONDISI MEJO ne tidak disewa
  const nomerc_meja = req.params._id  
  users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{
    warung.findOne({where:{id_pemilik:wong.id_user}}).then(warong=>{      
      meja.update({id_pemesan : 1 },{where :{nomer_meja : nomerc_meja , id_warung : warong.mejaWarung}}).then(cekTempat=>{
        if(cekTempat){
          req.session.message = {
            type: 'success',
            intro: 'Berhasil ',
            message: 'Status Meja Sudah berubah'
          }  
          res.redirect('/Admintempat')   
        }else{
          req.session.message = {
            type: 'danger',
            intro: 'ERROR !',
            message: 'Terjadi Kesalahan'
          }  
          res.redirect('/Admintempat')   
        }
      })
    })
  })
}

exports.cekTempat=(req,res)=>{
  ids = req.params._id
  users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{
    warung.findOne({where : { infoWarung : ids}}).then(cariW=>{
      if(cariW){
        console.log(cariW.mejaWarung);
        meja.findAll({where : {id_warung : cariW.mejaWarung}}).then(tempate=>{          
          // console.log(tempate);
          res.render('tempat',{data : tempate})
        })
      }else{
        req.session.message = {
          type: 'danger',
          intro: 'ERROR !',
          message: 'Terjadi Kesalahan'
        }
        res.redirect('/')
      }
    })
  })
}








//################################################################################################
//############################################################################################ POST
//#################################################################################################
exports.addWarung=(req,res)=>{  
  users.findOne({where:{id_user:req.decoded.idUser}}).then(user=>{
    if(req.files){
      var akhire = (req.files.wr.mimetype);        
      var jos = akhire.split('image/')[1]            
        if(jos == 'jpeg' || jos == 'jpg' || jos == 'png' ){
          let codeKonfirmasi = new Date().getTime() + idMenu_acak+ '.'+jos;          
          fs.writeFile('./public/uploads/' + codeKonfirmasi, req.files.wr.data, (err) => {
              if(err){console.log(err);}      
              var dataWarung = {
                id_pemilik  : user.id_user,
                nama_warung : req.body.namaWar,
                deskripsi   : req.body.deskripsi,
                infoWarung  : idInfo_acak,      
                menuWarung  : idMenu_acak,
                mejaWarung  : idMeja_acak,
                katerWarung : idKatr_acak,
                gambar      : codeKonfirmasi
              }   
              warung.findOne({where:{id_pemilik : user.id_user}}).then(cekAddWarung=>{
                if(cekAddWarung){
                  req.session.message = {
                    type: 'warning',
                    intro: 'info !',
                    message: 'Anda Diperbolehkan Menambah 1 Warung / Restaurant Saja'
                  }  
                  res.redirect('/warung')
                }
                else{
                  warung.create(dataWarung).then(buatWarung=>{
                    var data2={
                      lokasi : req.body.lokasi,
                      jamBuka: req.body.jb,
                      jamTutup: req.body.jt,
                      hp      : req.body.hp,
                      id_warung: dataWarung.infoWarung            
                    }
                    info.create(data2).then(tambahInfo=>{
                      req.session.message = {
                        type: 'success',
                        intro: 'Berhasil ',
                        message: 'Warung sudah ditambahkan'
                      }  
                      res.redirect('/warung')
                    })
                  })
                }
              })
          })
        }else{
          
        }            
      }else{
        res.redirect('/warung')
      }  
    })
}

exports.addMenu=(req,res)=>{
  users.findOne({where:{id_user:req.decoded.idUser}}).then(user=>{
    warung.findOne({where:{id_pemilik : user.id_user}}).then(dataWarung=>{
      if(req.files){        
        var akhire = (req.files.foo.mimetype);        
        var jos = akhire.split('image/')[1]            
        if(jos == 'jpeg' || jos == 'jpg' || jos == 'png' ){
          let codeKonfirmasi = new Date().getTime() + '.'+jos;
          fs.writeFile('./public/uploads/' + codeKonfirmasi, req.files.foo.data, (err) => {
              if(err){console.log(err);}      
          })                         
            var data={
              nama_menu : req.body.namaMak,
              harga_menu: req.body.hargaMak,
              desk_menu : req.body.deskripsi,
              gambar_menu : codeKonfirmasi,
              id_warung : dataWarung.menuWarung              
            }
            menu.create(data)                          
            req.session.message = {
              type: 'success',
              intro: 'Berhasil ',
              message: 'Menu sudah ditambahkan'
            } 
        }else{
          req.session.message = {
            type: 'danger',
            intro: 'ERROR !',
            message: 'Hanya jpeg / jpg / png yang diperbolehkan'
            }
        }
      }else{
        console.log("gk ono");
      }
      res.redirect('/Adminmenu')   
    })   
  })
}





exports.ubahSTa=(req,res)=>{
  users.findOne({where:{id_user : req.decoded.idUser}}) .then(user=>{
    warung.findOne({where:{id_pemilik : user.id_user}}).then(warong=>{                        
        info.update({S_tempat : 1},{where:{id_warung : warong.infoWarung}}).then(updateAktif=>{               
          res.redirect('/warung')
        })            
    })
  })
}
exports.ubahSTn=(req,res)=>{
  users.findOne({where:{id_user : req.decoded.idUser}}) .then(user=>{
    warung.findOne({where:{id_pemilik : user.id_user}}).then(warong=>{            
      info.update({S_tempat : 0},{where:{id_warung : warong.infoWarung}}).then(updateNonAktif=>{      
        res.redirect('/warung')
      })
    })
  })
}
exports.ubahSKa=(req,res)=>{
  users.findOne({where:{id_user : req.decoded.idUser}}) .then(user=>{
    warung.findOne({where:{id_pemilik : user.id_user}}).then(warong=>{      
      info.update({S_katering : 1},{where:{id_warung : warong.infoWarung}}).then(updateNonAktif=>{      
        res.redirect('/warung')
      })
    })
  })
}
exports.ubahSKn=(req,res)=>{
  users.findOne({where:{id_user : req.decoded.idUser}}) .then(user=>{
    warung.findOne({where:{id_pemilik : user.id_user}}).then(warong=>{      
      info.update({S_katering : 0},{where:{id_warung : warong.infoWarung}}).then(updateNonAktif=>{      
        res.redirect('/warung')
      })
    })
  })
}
exports.addMeja=(req,res)=>{
  users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{
    warung.findOne({where:{id_pemilik : wong.id_user}}).then(warong=>{
      var data={        
        id_pesan : idMeja_acak,
        nama_pemesan : '-',
        nomer_meja : req.body.nomMeja,
        keterangan : req.body.ketMeja,
        id_warung : warong.mejaWarung
      }
      meja.findOne({where:{nomer_meja : data.nomer_meja , id_warung : warong.mejaWarung}}).then(cekMeja=>{
        if(cekMeja > 0){
          req.session.message = {
            type: 'warning',
            intro: 'Warning !',
            message: 'Nomer Meja Sudah terdaftar pada restaurant Anda'
          }  
          res.redirect('/Admintempat')          
        }
        else{
          meja.create(data).then(tambahMeja=>{
            res.redirect('/Admintempat')            
          })
        }
      })
    })
  })
}



exports.tambahKater=(req,res)=>{
  var id = req.params._id
  var info = req.params._info
  if(info == 1){
  users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{    
    menu.findOne({where:{id_menuWarung : id}}).then(menune=>{
      if(menune){
        warung.findOne({where:{menuWarung : menune.id_warung}}).then(warong=>{
          if(warong){
            if(warong.id_pemilik != wong.id_user){  
              if(warong.set_bukatutup == 1 && warong.bukatutup == 1){                
                katr.findOne({where:{id_pemesan : wong.id_user , id_warung : warong.id_warung , status : 0}}).then(cekKatering=>{ 
                    if(cekKatering){                  
                      var ok = cekKatering.makanan                  
                      var combDATA1 = ok.split("m:")[1]                  
                      var combDATA2 = combDATA1.split(",")[1]

                      var data_makanan = combDATA1.split(",")[0] //DONE
                      var data_total   = combDATA2.split("t:")[1] //DONE                                                    
                      var lol = menune.harga_menu*req.body.jumlah      
                      var hargane = parseInt(cekKatering.harga) + parseInt(lol)                                                                                            
                      var totale = parseInt(data_total.split(" ")[1]) + parseInt(req.body.jumlah)                                                        
                      var dataUpdate={
                        makanan : 'm:'+data_makanan+menune.nama_menu+'{'+req.body.jumlah + '} , t: '+totale , harga : hargane
                      }                      
                      katr.update(dataUpdate,{where:{id_pemesan : wong.id_user , id_warung : warong.id_warung}}).then(done=>{
                        res.redirect('/katering/'+warong.infoWarung)
                      })                  
                    }
                    else{                                    
                      var data ={
                        id_pemesan : wong.id_user,
                        id_warung : warong.id_warung,
                        nama_penerima : wong.nama,
                        alamat_penerima : wong.alamat_kater,                    
                        makanan : 'm: '+menune.nama_menu+'{'+req.body.jumlah + '} , t: '+req.body.jumlah,
                        harga : menune.harga_menu*req.body.jumlah
                      }
                      katr.create(data).then(done=>{
                        res.redirect('/katering/'+warong.infoWarung)
                      })
                    }
                })
              }else{
                req.session.message = {
                  type: 'danger',
                  intro: 'ERROR !',
                  message: 'Resto / Warung sedang Tutup'
                } 
                res.redirect('/beranda')
              }
            }else{
              req.session.message = {
                type: 'danger',
                intro: 'ERROR !',
                message: 'Anda Tidak dapat Memesan Barang anda'
              } 
              res.redirect('/beranda')
            }
          }else{
            req.session.message = {
              type: 'danger',
              intro: 'ERROR !',
              message: 'Terjadi Kesalahan'
            } 
            res.redirect('/beranda')
          }
        })
      }else{
        req.session.message = {
          type: 'danger',
          intro: 'ERROR !',
          message: 'Terjadi Kesalahan'
        } 
        res.redirect('/beranda')
      }
    })
  })  
  }else if(info == 2){                //CHECK OUT
    katr.findOne({where:{id_katering : id}}).then(dataKater=>{
      if(dataKater.id_pemesan == req.decoded.idUser){
        warung.findOne({where:{id_warung : dataKater.id_warung}}).then(warong=>{        
          if(warong.set_bukatutup == 1 && warong.bukatutup == 1){
            var ok = dataKater.makanan                  
            var combDATA1 = ok.split("m:")[1]                  
            var combDATA2 = combDATA1.split(",")[1]            
            var data_total   = combDATA2.split("t:")[1] //DONE    
            var p = data_total.split(" ")[1]                                                                        
            if(p < 5){
              req.session.message = {
                type: 'warning',
                intro: 'Perhatian !',
                message: 'Minimal Total adalah 5'
              } 
              res.redirect('/katering/'+warong.infoWarung)
            }
            else{
             res.render('katerNext',{data : dataKater}) 
            }            
          }else{
            req.session.message = {
              type: 'danger',
              intro: 'ERROR !',
              message: 'Warung / Resto sedang Tutup'
            } 
            res.redirect('/beranda')
          }
        })
      }else{
        req.session.message = {
          type: 'danger',
          intro: 'ERROR !',
          message: 'Terjadi Kesalahan'
        } 
        res.redirect('/beranda')
      }
    })
  }
  else if(info == 3){             //PEMBAYARAN
    users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{
      katr.findOne({where:{id_katering : id}}).then(dataKater=>{        
        if(wong.saldo < dataKater.harga){
          req.session.message = {
            type: 'danger',
            intro: 'ERROR !',
            message: 'Saldo Tidak Mencukupi'
          } 
          res.redirect('/beranda')
        }else{   
          var datae={
            waktu_ambil : req.body.wkt ,
            status : 1
          }
          console.log(datae);
          katr.update(datae,{where:{id_pemesan : wong.id_user , id_katering : id}}).then(update1=>{
            if(update1){                            
              warung.findOne({where:{id_warung : dataKater.id_warung}}).then(warsq=>{                
                users.findOne({where:{id_user : warsq.id_pemilik}}).then(pemilike=>{                  
                  users.update({saldo : parseInt(pemilike.saldo) + parseInt(dataKater.harga)},{where:{id_user : pemilike.id_user}})                  
                  users.update({saldo : wong.saldo - dataKater.harga},{where:{id_user : wong.id_user}})                  
                  req.session.message = {
                    type: 'success',
                    intro: 'Berhasil !',
                    message: 'Pesanan Akan Dikirimkan'
                  } 
                  res.redirect('/beranda')
                })
              })              
            }else{
              req.session.message = {
                type: 'danger',
                intro: 'ERROR !',
                message: 'Terjadi Kesalahan'
              } 
              res.redirect('/beranda')
            }
          })
        }
      })
    })
  }
  else{
    res.redirect('/')
  }
}
exports.admin=(req,res)=>{
  const tokens = req.cookies.admin;  
  if (!tokens) return res.status(401).redirect("/");
    jwt.verify(tokens, "admins", (err, decoded) => {
      if(err){res.redirect('/login')}
      else{
        tarik.findAll({}).then(tarike=>{
          topup.findAll({where : {status : 0}}).then(topupe=>{          
            res.render('admin',{dataTarik : tarike , dataTop : topupe})
          })
        })        
      }
  });
}

exports.settingadmin=(req,res)=>{
  const tokens = req.cookies.admin;  
  if (!tokens) return res.status(401).redirect("/");
    jwt.verify(tokens, "admins", (err, decoded) => {
      if(err){res.redirect('/login')}
      else{
        var key = req.params.key
        if(key.split("_")[1] == 'tarik'){
          tarik.findOne({where:{id_tr : key.split("_")[0]}}).then(info=>{
            if(info.status == 0){
              tarik.update({status :1 },{where :{id_tr : info.id_tr}})
              res.redirect('/admin')
            }else{
              req.session.message = {
                type: 'danger',
                intro: 'ERROR !',
                message: 'Terjadi Kesalahan'
                }
                res.redirect('/admin')
            }
          })
        }else if(key.split("_")[1] == 'topup'){                           
          topup.findOne({where:{id_tp : key.split("_")[0]}}).then(info=>{
            users.findOne({where:{id_user : info.id_user}}).then(wong=>{              
            if(info.status == 0){              
              users.update({saldo : parseInt(info.jumlah) + parseInt(wong.saldo)},{where:{id_user : wong.id_user}})
              topup.update({status : 1 } , {where : {id_tp : info.id_tp}})
              res.redirect('/admin')
            }else{
              req.session.message = {
                type: 'danger',
                intro: 'ERROR !',
                message: 'Terjadi Kesalahan'
                }
                res.redirect('/admin')
            }
            })
          })
        }else if(key.split("_")[1] == 'rejectTopup'){                           
          topup.findOne({where:{id_tp : key.split("_")[0]}}).then(info=>{            
            if(info.status == 0){                                          
              topup.destroy({where : {id_tp : info.id_tp}})
              res.redirect('/admin')
            }else{
              req.session.message = {
                type: 'danger',
                intro: 'ERROR !',
                message: 'Terjadi Kesalahan'
                }
                res.redirect('/admin')
            }            
          })
        }else{
          req.session.message = {
            type: 'danger',
            intro: 'ERROR !',
            message: 'invalid'
            }
            res.redirect('/admin')
        }       
      }
  });  
}
exports.tariktunai=(req,res)=>{
  users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{
    var j = req.body.jumlah
    var r = req.body.rek
    if(j < 50000 || j > 500000){
      req.session.message = {
        type: 'danger',
        intro: 'ERROR !',
        message: 'Tidak Sesuai'
        }
        res.redirect('/profile')
    }else{
      if(wong.saldo < j){
        req.session.message = {
          type: 'danger',
          intro: 'ERROR !',
          message: 'Saldo Anda Tidak Mencukupi'
          }
          res.redirect('/profile')
      }else{      
        wong.update({saldo : wong.saldo - j},{where:{id_user : wong.id_user}})
        tarik.create({rekening : r,jumlah : 'Rp.'+j , id_user : wong.id_user , status : 0})
        req.session.message = {
          type: 'success',
          intro: 'Berhasil !',
          message: 'Permintaan Anda Sedang di proses oleh admin.'
          }
          res.redirect('/profile')
      }
    }
  })
}
exports.topup=(req,res)=>{
  users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{
    if(req.files){        
      var akhire = (req.files.zxc.mimetype);        
      var jos = akhire.split('image/')[1]            
      if(jos == 'jpeg' || jos == 'jpg' || jos == 'png' ){
        let codeKonfirmasi = new Date().getTime() + wong.id_user+ '.'+jos;
        console.log(codeKonfirmasi);
        fs.writeFile('./public/uploads/' + codeKonfirmasi, req.files.zxc.data, (err) => {
            if(err){console.log(err);}      
        })                         
          var data={
            fotone : codeKonfirmasi,
            id_user : wong.id_user           ,
            jumlah : req.body.jumlah
          }
          topup.create(data)                          
          req.session.message = {
            type: 'success',
            intro: 'Berhasil ',
            message: 'Gambar sedang diverfikasi oleh admin , silahkan tunggu'
          } 
          res.redirect('/profile')
      }else{
        req.session.message = {
          type: 'danger',
          intro: 'ERROR !',
          message: 'Hanya jpeg / jpg / png yang diperbolehkan'
          }
          res.redirect('/profile')
      }
    }else{
      req.session.message = {
        type: 'danger',
        intro: 'ERROR !',
        message: 'Gambar Di butuhkan'
        }
        res.redirect('/profile')
    }
  })
}