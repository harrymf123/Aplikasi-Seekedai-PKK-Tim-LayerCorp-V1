const jwt = require('jsonwebtoken'),
    url = require('url'),
    waktu = require('date-and-time'),
    gen_rate = require('star-ratings'),
    qrm = require('qr-image'),
    fs = require('fs'),
    forD = new Date(),
    hari = waktu.format(forD, 'dddd')
jam = waktu.format(forD, 'HH:mm'),
    users = require('../models/sc_auth'),
    warung = require("../models/sc_warung"),
    info = require("../models/sc_infoWarung"),
    meja = require("../models/sc_pesanMeja"),
    katr = require("../models/sc_pesanKat"),
    fileQR = require("../models/sc_qr"),
    menu = require("../models/sc_menuWarung"),    
    conn = require('../models/sc_database'),
    idInfo_acak = Math.floor(Math.random() * Math.floor(999999)),
    idMenu_acak = Math.floor(Math.random() * Math.floor(999999)),
    idMeja_acak = Math.floor(Math.random() * Math.floor(999999)),
    idKatr_acak = Math.floor(Math.random() * Math.floor(999999))



// ####################################     INFO WARUNG     ####################################################
// #############################################################################################################
exports.warung = (req, res) => {
    users.findOne({ where: { id_user: req.decoded.idUser } }).then(user => {
        const idUser = user.id_user
        warung.findOne({ where: { id_pemilik: user.id_user } }).then(cekWarung => {
            if (cekWarung) {
                var sql =
                    "SELECT * FROM warungs"
                    + " INNER JOIN info_warungs ON warungs.infoWarung = info_warungs.id_warung WHERE id_pemilik = ? "
                conn.db.query(sql, idUser, (err, hasil) => {                    
                    console.log(hasil[0].rate_b);
                    res.render('warung', { data: hasil[0] })
                })
            }
            else {
                res.render('warung', { data: 0 })
            }
        })
    })
}
exports.setLibur=(req,res)=>{
    const info = req.params.info
    users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{    
        if(info == 'buka'){
            warung.findOne({where:{id_pemilik : wong.id_user}}).then(updateBuka=>{
                if(updateBuka){
                    warung.update({set_bukatutup : 1},{where:{id_warung : updateBuka.id_warung}}).then(done=>{
                        console.log(done);
                        res.redirect('/warung')
                    })
                }else{res.redirect('/warung')}
            })
        }
        else if(info == 'tutup'){
            warung.findOne({where:{id_pemilik : wong.id_user}}).then(updateTutup=>{
                if(updateTutup){
                    warung.update({set_bukatutup : 0},{where:{id_warung : updateTutup.id_warung}}).then(done=>{
                        console.log(done);
                        res.redirect('/warung')
                    })
                }else{res.redirect('/warung')}
            })
        }
        else{
            res.redirect('/warung')
        }
    })
}

exports.hapusWarung=(req,res)=>{
    users.findOne({where:{id_user:req.decoded.idUser}}).then(wong=>{
        warung.findOne({where:{id_pemilik : wong.id_user}}).then(infoWarung=>{            
            infoWarung.destroy({where:{id_warung : infoWarung.infoWarung}}).then(hapusINFO=>{
                if(hapusINFO){
                    menu.destroy({where:{id_warung : infoWarung.menuWarung}}).then(hapusMENU=>{
                        if(hapusMENU){
                            meja.destroy({where:{id_warung:infoWarung.mejaWarung}}).then(hapusTEMPAT=>{
                                if(hapusTEMPAT){
                                    warung.destroy({where:{id_warung : infoWarung.id_warung}}).then(hapusWARUNG=>{
                                        if(hapusWARUNG){
                                            console.log("Sukses hapus");
                                            res.redirect('/warung')
                                        }else{console.log("Hapus Warung = 0"); res.redirect('/warung')}
                                    })
                                }else{console.log("Hapus hapus = 0"); res.redirect('/warung')}
                            })
                        }else{console.log("Hapus menu = 0"); res.redirect('/warung')}
                    })
                }else{console.log("Hapus Warung = 0"); res.redirect('/warung')}
            })
        })
    })
}

exports.edit1Warung = (req, res) => {    
    var idne = req.body.idne
    var data = {
        nama_warung: req.body.namaWar,
        deskripsi: req.body.deskripsi
    }
    if(req.files){
        var akhire = (req.files.wr.mimetype);        
        var jos = akhire.split('image/')[1]            
          if(jos == 'jpeg' || jos == 'jpg' || jos == 'png' ){
            let codeKonfirmasi = new Date().getTime() + idMenu_acak+ '.'+jos;          
            fs.writeFile('./public/uploads/' + codeKonfirmasi, req.files.wr.data, (err) => {
                if(err){console.log(err);}
            })            
            var data1 = {
                nama_warung: req.body.namaWar,
                deskripsi: req.body.deskripsi,
                gambar : codeKonfirmasi
            }            
            users.findOne({ where: { id_user: req.decoded.idUser } }).then(user => {                
                warung.findOne({ where: { id_pemilik: user.id_user } }).then(cekWarung => {                    
                    if (cekWarung) {                        
                        warung.update(data1, { where: { id_pemilik: user.id_user } }).then(updateWarung => {                            
                            if (updateWarung) {
                                req.session.message = {
                                    type: 'success',
                                    intro: 'Berhasil !',
                                    message: 'Sukses update data'
                                }
                                res.redirect('/warung')
                            } else {
                                res.redirect('/warung')
                            }
                        })
                    }
                    else {
                        req.session.message = {
                            type: 'danger',
                            intro: 'Gagal !',
                            message: 'terjadi Kesalahan'
                        }
                        res.redirect('/warung')
                    }
                })
            })
        }else{
            req.session.message = {
                type: 'danger',
                intro: 'Gagal !',
                message: 'Hanya Gambar Yang diperbolehkan'
            }
            res.redirect('/warung')
        }
    }else{        
        users.findOne({ where: { id_user: req.decoded.idUser } }).then(user => {
            warung.findOne({ where: { id_pemilik: user.id_user } }).then(cekWarung => {
                if (cekWarung) {
                    warung.update(data, { where: { id_pemilik : user.id_user } }).then(updateWarung => {
                        if (updateWarung) {
                            req.session.message = {
                                type: 'success',
                                intro: 'Berhasil !',
                                message: 'Sukses update data'
                            }
                            res.redirect('/warung')
                        } else {
                            res.redirect('/warung')
                        }
                    })
                }
                else {
                    req.session.message = {
                        type: 'danger',
                        intro: 'Gagal !',
                        message: 'terjadi Kesalahan'
                    }
                    res.redirect('/warung')
                }
            })
        })
    }    
}

exports.edit2Warung = (req, res) => {
    var idne = req.body.idne
    var data = {
        lokasi: req.body.lokasi,
        jamBuka: req.body.jb,
        jamTutup: req.body.jt,
        hp: req.body.hp
    }
    users.findOne({ where: { id_user: req.decoded.idUser } }).then(user => {
        info.update(data, { where: { id_infoWarung: idne } }).then(updateWarung => {
            if (updateWarung) {
                req.session.message = {
                    type: 'success',
                    intro: 'Berhasil !',
                    message: 'Sukses update data'
                }
                res.redirect('/warung')
            } else {
                res.redirect('/warung')
            }
        })
    })
}



//#####################         MENU WARUNG         ##################################################################
//####################################################################################################################
exports.menuWarung = (req, res) => {
    users.findOne({ where: { id_user: req.decoded.idUser } }).then(user => {
        var sql =
            "SELECT warungs.nama_warung ,id_menuWarung , nama_menu , harga_menu , desk_menu ,  gambar_menu FROM warungs"
            + " INNER JOIN menu_warungs ON warungs.menuWarung = menu_warungs.id_warung WHERE id_pemilik = ?";
        conn.db.query(sql, user.id_user, (err, hasil) => {
            if (hasil) {                
                res.render('menu_warung', { data: hasil })
            }
            else {
                res.render('menu_warung', { data: 0 })
            }
        })
    })
}
exports.hapusMenu = (req, res) => {
    idBarang = req.params.id
    users.findOne({ where: { id_user: req.decoded.idUser } }).then(user => {
        menu.findOne({ where: { id_menuWarung: idBarang } }).then(cekBarang => {
            if (cekBarang) {
                warung.findOne({ where: { menuWarung: cekBarang.id_warung } }).then(cekWarung => {
                    if (cekWarung.id_pemilik != user.id_user) {
                        req.session.message = {
                            type: 'danger',
                            intro: 'ERROR !',
                            message: 'Menu Makanan Tidak Tersedia'
                        }
                        res.redirect('/Adminmenu')
                    }
                    else {
                        menu.destroy({ where: { id_menuWarung: idBarang } }).then(selesai => {
                            req.session.message = {
                                type: 'success',
                                intro: 'Berhasil ',
                                message: 'Menu Makanan Sudah Dihapus'
                            }
                            res.redirect('/Adminmenu')
                        })
                    }
                })
            }
            else {
                req.session.message = {
                    type: 'danger',
                    intro: 'ERROR !',
                    message: 'Menu Makanan Tidak Tersedia'
                }
                res.redirect('/Adminmenu')
            }
        })
    })
}

exports.editMenu = (req, res) => {
    var idBarang = req.body.idne
    var data = {
        nama_menu: req.body.namaMak,
        harga_menu: req.body.hargaMak,
        desk_menu: req.body.deskripsi
    }
    if (data.nama_warung == '' || data.harga_menu == '' || data.desk_menu == '') {
        console.log("Dilarang Kosong");
    } else {
        users.findOne({ where: { id_user: req.decoded.idUser } }).then(user => {
            menu.findOne({ where: { id_menuWarung: idBarang } }).then(cekBarang => {
                if (cekBarang) {
                    warung.findOne({ where: { menuWarung: cekBarang.id_warung } }).then(cekWarung => {
                        if (cekWarung.id_pemilik != user.id_user) {
                            req.session.message = {
                                type: 'danger',
                                intro: 'ERROR !',
                                message: 'Menu Makanan Tidak Tersedia'
                            }
                            res.redirect('/Adminmenu')
                        }
                        else {
                            menu.update(data, { where: { id_menuWarung: cekBarang.id_menuWarung } }).then(selesai => {
                                req.session.message = {
                                    type: 'success',
                                    intro: 'Berhasil !',
                                    message: 'Menu Makanan sudah di update'
                                }
                                res.redirect('/Adminmenu')
                            })
                        }
                    })
                }
                else {
                    req.session.message = {
                        type: 'danger',
                        intro: 'ERROR !',
                        message: 'Menu Makanan Tidak Tersedia'
                    }
                    res.redirect('/Adminmenu')
                }
            })
        })
    }
}

exports.rate=(req,res)=>{
    const b = req.params.bintang
    const id = req.params.id    
    users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{
        fileQR.findOne({where:{id_qr : id}}).then(infoKONFIR=>{
            if(infoKONFIR){
                if(infoKONFIR.id_user == wong.id_user){
                    if(infoKONFIR.rate == 0){
                        if(b > 0 && b <=5){
                            meja.findOne({where:{id_pesan : infoKONFIR.id_meja}}).then(infoMEJA=>{
                                warung.findOne({where:{ mejaWarung: infoMEJA.id_warung}}).then(infoWARUNG=>{
                                    info.findOne({where:{id_warung : infoWARUNG.infoWarung}}).then(gas=>{                                    
                                        if(b == 1){
                                            info.update({b1: gas.b1 + 1},{where:{id_warung : infoWARUNG.infoWarung}})
                                        }
                                        else if(b == 2){
                                            info.update({b2: gas.b2 + 1},{where:{id_warung : infoWARUNG.infoWarung}})
                                        }
                                        else if(b == 3){
                                            info.update({b3: gas.b3 + 1},{where:{id_warung : infoWARUNG.infoWarung}})
                                        }
                                        else if(b == 4){
                                            info.update({b4: gas.b4 + 1},{where:{id_warung : infoWARUNG.infoWarung}})
                                        }
                                        else{
                                            info.update({b5: gas.b5 + 1},{where:{id_warung : infoWARUNG.infoWarung}})
                                        }
                                        fileQR.update({rate : 1},{where : {id_qr : id}}).then(done=>{
                                            res.redirect('/riwayat')
                                        })                                        
                                    })
                                })
                            })
                        }else{
                            req.session.message = {
                                type: 'danger',
                                intro: 'ERROR !',
                                message: 'Terjadi Kesalahan /Sqk6'
                            }
                            res.redirect('/riwayat')
                        }
                    }else{
                        req.session.message = {
                            type: 'danger',
                            intro: 'ERROR !',
                            message: 'Terjadi Kesalahan /Jw1h'
                        }
                        res.redirect('/riwayat')
                    }
                }else{
                    req.session.message = {
                        type: 'danger',
                        intro: 'ERROR !',
                        message: 'Terjadi Kesalahan /xHw2'
                    }
                    res.redirect('/riwayat')
                }
            }else{
                req.session.message = {
                    type: 'danger',
                    intro: 'ERROR !',
                    message: 'Terjadi Kesalahan /Sb8f'
                }
                res.redirect('/riwayat')
            }
        })
    })
}
exports.scancode=(req,res)=>{
    res.render('scanqr')
}