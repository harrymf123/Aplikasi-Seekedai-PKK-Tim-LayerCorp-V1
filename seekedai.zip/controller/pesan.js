const   jwt     =   require('jsonwebtoken'),        
        qrm     =   require('qr-image'),
        fs      =   require('fs'),        
        waktu   =   require('date-and-time'),
        forD    =   new Date(),        
        bulan   =   waktu.format(forD, 'MM')       
        tglCnf  =   waktu.format(forD, 'DD')  
        jam     =   waktu.format(forD, 'HH:mm'),
        users   =   require('../models/sc_auth'),
        warung  =   require("../models/sc_warung"),
        info    =   require("../models/sc_infoWarung"),
        meja    =   require("../models/sc_pesanMeja"),
        katr    =   require("../models/sc_pesanKat"),
        menu    =   require("../models/sc_menuWarung"),
        fileQR  =   require("../models/sc_qr"),
        conn    =   require('../models/sc_database'),        
    idInfo_acak =   Math.floor(Math.random() * Math.floor(999999)),    
    idMenu_acak =   Math.floor(Math.random() * Math.floor(999999)),
    idMeja_acak =   Math.floor(Math.random() * Math.floor(999999)),
    idKatr_acak =   Math.floor(Math.random() * Math.floor(999999))


//GET

exports.pembayaran = (req,res)=>{
    const as = req.params.tokencash  
    if (!as) return res.status(401).redirect("/");
      jwt.verify(as, "%pembayaranUSER%", (err, cash) => {
        if(err){res.redirect('/')}
        else{
          meja.findOne({where:{id_pesan : cash.datane}}).then(warong=>{
            res.render('page_order',{data : warong })
          })
        }
    });     
  } 

exports.bayar=(req,res)=>{  
    const idP = req.params.id   
    const ipt = {
      ket_waktu2 : req.body.tanggal ,
      ket_waktu3 : req.body.jam
    }    
    if(!req.session.pembayaran){
      req.session.message = {
        type: 'danger',
        intro: 'ERROR !',
        message: 'Terjadi Kesalahan'
      }  
      res.redirect('/beranda')
    }
    else{                
      users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{
        meja.findOne({where:{id_pesan : idP}}).then(cekMeja=>{
          if(cekMeja){            
            // var tanggalDepan = forD.getDate()+1                                    
            // var tahun        = forD.getFullYear()
            // var e = ipt.ket_waktu2
            // var tIpt = e.split("-")[2]      
            // var bIpt = e.split("-")[1]
            // var thIpt = e.split("-")[0]            
            // if(tIpt <= tanggalDepan && bIpt == bulan && thIpt == tahun){              
            //   if(tIpt < tglCnf){
            //     console.log("error line 64");                
            //     req.session.message = {
            //       type: 'danger',
            //       intro: 'ERROR !',
            //       message: 'Terjadi Kesalahan'                  
            //     }  
            //     console.log("Pesan hari Kemarin");
            //     res.redirect('/beranda')                
            //   }else{      
                
                
                // var akhirBulan = new Date(tahun, forD.getMonth() + 1, 0);
                // var tess = akhirBulan.split("-","T")[2]
                // console.log(tess);
                // if(akhirBulan)                                                                  
                    if(wong.saldo < 5000){
                      req.session.message = {
                            type: 'danger',
                            intro: 'ERROR !',
                            message: 'Dana Tidak Mencukupi'
                          }  
                          res.redirect('/beranda')
                    }else{
                      users.update({saldo : wong.saldo - 5000},{where:{id_user : wong.id_user}})                    
                      req.decoded.orderan = true 
                      meja.update({id_pemesan : wong.id_user,nama_pemesan : wong.nama},{where:{id_warung : cekMeja.id_warung , id_pesan : idP}}).then(done=>{
                          res.redirect('/nextPesan/'+cekMeja.nomer_meja+'/'+cekMeja.id_warung)
                      })
                    }                                                          
                // } 
            //   }

            // }else{
            //   req.session.message = {
            //     type: 'danger',
            //     intro: 'ERROR !',
            //     message: 'Maksimal Pemesanan 1 hari dari sekarang'
            //   }  
            //   console.log(tIpt +"<="+ tanggalDepan +"+"+ bIpt +"=="+ bulan +"+"+ thIpt +"=="+ tahun);
            //   console.log("maksimal");
            //   res.redirect('/beranda')
            // }
        }else{
          req.session.message = {
            type: 'danger',
            intro: 'ERROR !',
            message: 'Terjadi Kesalahan'
          }  
          console.log("eror line 106");
          res.redirect('/beranda')
        } 
      })
    })
    }
}  


exports.pesanT=(req,res)=>{           // http://localhost/pesan

    users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{    
      meja.findOne({where:{nomer_meja : req.params._mejane , id_warung : req.params._wr}}).then(warong=>{      
        if(warong){
          warung.findOne({where:{mejaWarung : warong.id_warung}}).then(cekLagi=>{
            if(cekLagi.set_bukatutup == 1){
              if(cekLagi.bukatutup == 1){
                if(cekLagi.id_pemilik == wong.id_user){
                  req.session.message = {
                    type: 'danger',
                    intro: 'ERROR !',
                    message: 'Tidak Dapat Memesan Tempat Anda Sendiri'
                  }  
                  res.redirect('/beranda')
                }else{                                    
                    const data ={datane : warong.id_pesan}
                    const token = jwt.sign(data, "%pembayaranUSER%", {expiresIn: 900000}); 
                    req.session.pembayaran = true
                    res.redirect('/pembayaran/'+token)
                }
              }else{
                req.session.message = {
                  type: 'danger',
                  intro: 'ERROR !',
                  message: 'Restaurant / Warung Tutup'
                }  
                res.redirect('/beranda')
              }
            }else{
              req.session.message = {
                type: 'danger',
                intro: 'ERROR !',
                message: 'Maaf Pihak Restaurant / Warung Hari Waktu ini libur'
              }  
              res.redirect('/beranda')            
            }
          })
        }
        else{
          req.session.message = {
            type: 'danger',
            intro: 'ERROR !',
            message: 'Terjadi Kesalahan'
          }  
          res.redirect('/beranda')
        } 
      })
    })
  }
  
  
  
  
exports.nextPesanT=(req,res)=>{         //TAHAP AKHIR GENERATE QR
    if(!req.session.pembayaran && !req.session.orderan){
      req.session.message = {
        type: 'warning',
        intro: 'Perhatian ,',
        message: 'Pesanan Sudah Tersimpan di History .'
      }        
      res.redirect('/beranda')
    }
    else{
    users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{    
      meja.findOne({where:{nomer_meja : req.params._mejane , id_warung : req.params._wr}}).then(warong=>{      
        if(warong){
          warung.findOne({where:{mejaWarung : warong.id_warung}}).then(cekLagi=>{
            if(cekLagi.id_pemilik == wong.id_user){
              req.session.message = {
                type: 'danger',
                intro: 'ERROR !',
                message: 'Tidak Dapat Memesan Tempat Anda Sendiri'
              }  
              res.redirect('/beranda')
            }else{            
              const data = {
                idMeja      : req.params._mejane,
                idRest      : req.params._wr,
                idPembeli   : wong.id_user,
                pembeli     :  wong.nama
                };
              const token = jwt.sign(data, "%generateQR%", {expiresIn: "2h"});      
                let urlKonfirmasi = ('http://localhost/confirm/tempat/'+token)    
                var gambare = qrm.imageSync(urlKonfirmasi,{ type: 'png'})  
                let codeKonfirmasi = new Date().getTime() + '.png';
                console.log(gambare);
                fs.writeFileSync('./public/qr/' + codeKonfirmasi, gambare, (err) => {
                    if(err){console.log(err);}      
                })  
                var dataGambar = "qr/" + codeKonfirmasi
                var nambahQR = {
                    id_user : wong.id_user,
                    gambar_qr : dataGambar,
                    id_meja :  warong.id_pesan ,
                    nama_meja : warong.nomer_meja,
                    nama_resto : cekLagi.nama_warung,
                    status : 0,       
                    waktu : tglCnf+' '+waktu.format(forD,'MMMM')+' '+waktu.format(forD,'YYYY')+' ,Jam : '+jam+'-'+waktu.format(forD,'A')          
                }
                fileQR.create(nambahQR).then(selesai=>{
                    console.log(urlKonfirmasi);
                    req.session.pembayaran = false
                    res.render('page_generate',{data:dataGambar})
                })
            }
          })
        }
        else{
          req.session.message = {
            type: 'danger',
            intro: 'ERROR !',
            message: 'Terjadi Kesalahan'
          }  
          res.redirect('/beranda')
        } 
      })
    })
   } 
  }
  
exports.konfirT=(req,res)=>{
    const as = req.params._as  
    if (!as) return res.status(401).redirect("/");
      jwt.verify(as, "%generateQR%", (err, qr) => {
        if(err){res.redirect('/')}
        else{
          users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{
              warung.findOne({where:{mejaWarung : qr.idRest}}).then(warong=>{
                  meja.findOne({where:{nomer_meja : qr.idMeja , id_warung : warong.mejaWarung}}).then(cekMeja=>{
                      if(cekMeja){
                        if(wong.id_user == warong.id_pemilik){
                            // console.log("lanjut");
                            meja.update({id_pemesan : 0 , nama_pemesan : '-'},{where:{nomer_meja : qr.idMeja , id_warung : warong.mejaWarung}}).then(apdetMeja=>{
                                fileQR.update({status : 1},{where:{id_user : qr.idPembeli,id_meja : cekMeja.id_pesan}}).then(apdetqr=>{                                    
                                    req.session.message = {
                                        type: 'success',
                                        intro: 'Berhasil ',
                                        message: 'Sukses Chekout'
                                      }
                                    res.redirect('/beranda')
                                })
                            })
                        }else{
                            req.session.message = {
                                type: 'danger',
                                intro: 'ERROR !',
                                message: 'Hanya Admin Restaurant Yang dapat mengakses URL ini'
                              }
                              res.redirect('/beranda')
                        }
                      }else{
                        req.session.message = {
                            type: 'danger',
                            intro: 'ERROR !',
                            message: 'Terjadi Kesalahan'
                          }
                          res.redirect('/beranda')
                      }
                  })
              })
          })
        }
    });  
}

exports.history=(req,res)=>{
  console.log(waktu.format(forD,'A'));
  users.findOne({where:{id_user:req.decoded.idUser}}).then(wong=>{
    fileQR.findAll({where:{id_user : wong.id_user,status : 0 }}).then(ok=>{  
      fileQR.findAll({where:{id_user : wong.id_user,status : 1 }}).then(oke=>{          
        fileQR.findAndCountAll({where:{id_user : wong.id_user,status : 1}}).then(koun=>{                      
            res.render('riwayat',{data:ok , sukses : koun.count ,data2 : oke})
          })
        })
      })               
    })
}
exports.hapusKater=(req,res)=>{
  warung.findOne({where:{infoWarung : req.params.key}}).then(wrs=>{
    katr.destroy({where:{id_pemesan : req.decoded.idUser , id_warung : wrs.id_warung}})
    res.redirect('/katering/'+req.params.key)
  })  
}

exports.done=(req,res)=>{
  var key = req.params.key
  users.findOne({where:{id_user : req.decoded.idUser}}).then(wong=>{    
    katr.findOne({where:{id_katering : key}}).then(pesanan=>{    
      warung.findOne({where:{id_warung : pesanan.id_warung}}).then(infoWarung=>{
        if(pesanan){                  
          if(infoWarung.id_pemilik == wong.id_user){      
            katr.update({status:2},{where:{id_katering : key}})
            res.redirect('/Adminkatering')
          }else{
            req.session.message = {
              type: 'danger',
              intro: 'ERROR !',
              message: 'Terjadi Kesalahan'
            }
            res.redirect('/Adminkatering')
          }
        }else{
          req.session.message = {
            type: 'danger',
            intro: 'ERROR !',
            message: 'Terjadi Kesalahan'
          }
          res.redirect('/Adminkatering')
        }
      })            
    })
  })
}