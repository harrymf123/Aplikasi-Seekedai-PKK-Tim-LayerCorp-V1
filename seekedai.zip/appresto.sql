-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2020 at 02:58 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `appresto`
--

-- --------------------------------------------------------

--
-- Table structure for table `info_warungs`
--

CREATE TABLE `info_warungs` (
  `id_infoWarung` int(200) NOT NULL,
  `lokasi` varchar(200) NOT NULL,
  `jamBuka` varchar(200) NOT NULL,
  `jamTutup` varchar(200) NOT NULL,
  `hp` text NOT NULL,
  `b1` int(200) NOT NULL,
  `b2` int(200) NOT NULL,
  `b3` int(200) NOT NULL,
  `b4` int(200) NOT NULL,
  `b5` int(200) NOT NULL,
  `total_b` varchar(200) NOT NULL,
  `rate_b` varchar(200) NOT NULL,
  `S_tempat` int(200) NOT NULL,
  `S_katering` int(200) NOT NULL,
  `id_warung` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `info_warungs`
--

INSERT INTO `info_warungs` (`id_infoWarung`, `lokasi`, `jamBuka`, `jamTutup`, `hp`, `b1`, `b2`, `b3`, `b4`, `b5`, `total_b`, `rate_b`, `S_tempat`, `S_katering`, `id_warung`) VALUES
(359, 'Jalan Danau Ranau 11 G7G No.1', '06:00', '23:30', '8771511', 2, 0, 0, 1, 18, '21 Orang Menilai', '4.6', 1, 1, 270070),
(368, 'Mojokerto', '05:00', '12:30', '087715111965', 0, 0, 0, 0, 0, '19 Orang Menilai', '4.6', 0, 0, 664925);

-- --------------------------------------------------------

--
-- Table structure for table `menu_warungs`
--

CREATE TABLE `menu_warungs` (
  `id_menuWarung` int(200) NOT NULL,
  `nama_menu` varchar(200) NOT NULL,
  `harga_menu` int(200) NOT NULL,
  `desk_menu` varchar(200) NOT NULL,
  `gambar_menu` varchar(100) NOT NULL,
  `id_warung` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pket_warungs`
--

CREATE TABLE `pket_warungs` (
  `id_katering` int(200) NOT NULL,
  `id_pemesan` int(200) NOT NULL,
  `id_warung` int(200) NOT NULL,
  `nama_penerima` varchar(200) NOT NULL,
  `alamat_penerima` varchar(200) NOT NULL,
  `waktu_ambil` varchar(200) NOT NULL,
  `makanan` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `harga` varchar(200) NOT NULL,
  `status` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pket_warungs`
--

INSERT INTO `pket_warungs` (`id_katering`, `id_pemesan`, `id_warung`, `nama_penerima`, `alamat_penerima`, `waktu_ambil`, `makanan`, `harga`, `status`) VALUES
(1262, 1051, 10972, 'qwe', 'Mojokerto', '', 'm: Lalapan Ayam Goreng{5} , t: 5', '60000', 2),
(1263, 1051, 10972, 'qwe', 'Mojokerto', '', 'm: Lalapan Ayam Goreng{5} , t: 5', '60000', 2),
(1264, 1051, 10972, 'qwe', 'Mojokerto', '12:42', 'm: Lalapan Ayam Goreng{5} , t: 5', '60000', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pmeja_warungs`
--

CREATE TABLE `pmeja_warungs` (
  `id_pesan` int(200) NOT NULL,
  `nomer_meja` text NOT NULL,
  `id_pemesan` int(11) NOT NULL,
  `nama_pemesan` varchar(20) NOT NULL,
  `id_warung` int(200) NOT NULL,
  `keterangan` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tariks`
--

CREATE TABLE `tariks` (
  `id_tr` int(20) NOT NULL,
  `rekening` varchar(20) NOT NULL,
  `jumlah` text NOT NULL,
  `id_user` int(20) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tariks`
--

INSERT INTO `tariks` (`id_tr`, `rekening`, `jumlah`, `id_user`, `status`) VALUES
(4, '5439857987', 'Rp.50000', 1049, 1),
(5, '12041581', 'Rp.50000', 1049, 1),
(6, '1205710', 'Rp.50000', 1049, 1);

-- --------------------------------------------------------

--
-- Table structure for table `topups`
--

CREATE TABLE `topups` (
  `id_tp` int(20) NOT NULL,
  `fotone` varchar(200) NOT NULL,
  `id_user` int(20) NOT NULL,
  `jumlah` text NOT NULL,
  `status` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `topups`
--

INSERT INTO `topups` (`id_tp`, `fotone`, `id_user`, `jumlah`, `status`) VALUES
(1, '1587353022531.jpeg', 1049, '', 1),
(2, '1587377675403.jpeg', 1049, '500000', 1),
(3, '1587378095880.jpeg', 1049, '50000', 1),
(4, '1587378436734.jpeg', 1049, '40000', 1),
(5, '1587378698065.jpeg', 1049, '100000', 1),
(6, '1587380813023.jpeg', 1049, '50000', 1),
(8, '1587780836975.jpeg', 1049, '50000', 1),
(9, '1587781149639.jpeg', 1049, '10000', 1),
(10, '1587782378120.jpeg', 1051, '100000', 1),
(11, '1587807798340.jpeg', 1051, '100000', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(200) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `pass` varchar(200) NOT NULL,
  `hp` int(200) NOT NULL,
  `info` int(11) NOT NULL,
  `alamat_kater` varchar(200) NOT NULL,
  `saldo` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `nama`, `email`, `pass`, `hp`, `info`, `alamat_kater`, `saldo`) VALUES
(1049, 'asd', 'asd@asd', 'sha1$fea2dd20$1$fb3417d0ba13baac341a8ac621e217a583210d7a', 0, 0, '', 280000),
(1050, 'zxc', 'zxc@zxc', 'sha1$b402e7d9$1$51562df2b938fe85f5b01f4dccfa322506c33b3c', 0, 0, '', 0),
(1051, 'qwe', 'qwe@qwe', 'sha1$7f870135$1$9a62f7b3cfb7a775ed7ad708bb98655c34966cfd', 0, 0, 'Mojokerto', 10000);

-- --------------------------------------------------------

--
-- Table structure for table `users_qrs`
--

CREATE TABLE `users_qrs` (
  `id_qr` int(200) NOT NULL,
  `id_user` int(200) NOT NULL,
  `gambar_qr` varchar(200) NOT NULL,
  `id_meja` int(10) NOT NULL,
  `nama_meja` varchar(200) NOT NULL,
  `nama_resto` varchar(200) NOT NULL,
  `status` int(4) NOT NULL,
  `waktu` varchar(200) NOT NULL,
  `rate` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users_qrs`
--

INSERT INTO `users_qrs` (`id_qr`, `id_user`, `gambar_qr`, `id_meja`, `nama_meja`, `nama_resto`, `status`, `waktu`, `rate`) VALUES
(25, 1051, 'qr/1585362945571.png', 4, '1A', 'Warung Barokah', 1, '28 March 2020 ,Jam : 09:35-AM', 1),
(26, 1051, 'qr/1585363890944.png', 7, '2A', 'Warung Barokah', 1, '28 March 2020 ,Jam : 09:51-AM', 1),
(27, 1051, 'qr/1585726202487.png', 7, '2A', 'Warung Barokah', 1, '01 April 2020 ,Jam : 14:24-PM', 1),
(28, 1050, 'qr/1585726484851.png', 4, '1A', 'Warung Barokah', 1, '01 April 2020 ,Jam : 14:24-PM', 1),
(29, 1050, 'qr/1585726613452.png', 4, '1A', 'Warung Barokah', 1, '01 April 2020 ,Jam : 14:24-PM', 1),
(30, 1050, 'qr/1585726816433.png', 7, '2A', 'Warung Barokah', 1, '01 April 2020 ,Jam : 14:38-PM', 1),
(31, 1050, 'qr/1585727421152.png', 7, '2A', 'Warung Barokah', 1, '01 April 2020 ,Jam : 14:44-PM', 1),
(32, 1051, 'qr/1586485088734.png', 4, '1A', 'Warung Barokah', 1, '10 April 2020 ,Jam : 09:15-AM', 1),
(33, 1051, 'qr/1587348921107.png', 4, '1A', 'Warung Barokah', 1, '20 April 2020 ,Jam : 09:01-AM', 1),
(34, 1051, 'qr/1587519351816.png', 4, '1A', 'Warung Barokah', 1, '22 April 2020 ,Jam : 08:24-AM', 1),
(35, 1051, 'qr/1587524314804.png', 7, '2A', 'Warung Barokah', 1, '22 April 2020 ,Jam : 09:39-AM', 1),
(36, 1051, 'qr/1587526294277.png', 7, '2A', 'Warung Barokah', 1, '22 April 2020 ,Jam : 10:30-AM', 1),
(37, 1051, 'qr/1587527631369.png', 7, '2A', 'Warung Barokah', 1, '22 April 2020 ,Jam : 10:38-AM', 1),
(38, 1051, 'qr/1587527763529.png', 7, '2A', 'Warung Barokah', 1, '22 April 2020 ,Jam : 10:38-AM', 1),
(39, 1051, 'qr/1587527902382.png', 7, '2A', 'Warung Barokah', 1, '22 April 2020 ,Jam : 10:38-AM', 1),
(40, 1051, 'qr/1587528035765.png', 7, '2A', 'Warung Barokah', 1, '22 April 2020 ,Jam : 10:38-AM', 1),
(41, 1051, 'qr/1587709568670.png', 4, '1A', 'Warung Barokah', 1, '24 April 2020 ,Jam : 13:22-PM', 1),
(42, 1051, 'qr/1587709644803.png', 7, '2A', 'Warung Barokah', 1, '24 April 2020 ,Jam : 13:22-PM', 1),
(43, 1051, 'qr/1587774405446.png', 7, '2A', 'Warung Barokah', 1, '25 April 2020 ,Jam : 07:15-AM', 1),
(44, 1051, 'qr/1587781769060.png', 4, '1A', 'Warung Barokah', 1, '25 April 2020 ,Jam : 09:20-AM', 1),
(45, 1051, 'qr/1587782455582.png', 4, '1A', 'Warung Barokah', 0, '25 April 2020 ,Jam : 09:40-AM', 0);

-- --------------------------------------------------------

--
-- Table structure for table `warungs`
--

CREATE TABLE `warungs` (
  `id_warung` int(200) NOT NULL,
  `id_pemilik` int(200) NOT NULL,
  `nama_warung` varchar(200) NOT NULL,
  `deskripsi` varchar(200) NOT NULL,
  `infoWarung` int(200) NOT NULL,
  `menuWarung` int(200) NOT NULL,
  `mejaWarung` int(200) NOT NULL,
  `katerWarung` int(200) NOT NULL,
  `bukatutup` int(20) NOT NULL,
  `set_bukatutup` int(11) NOT NULL,
  `gambar` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `info_warungs`
--
ALTER TABLE `info_warungs`
  ADD PRIMARY KEY (`id_infoWarung`);

--
-- Indexes for table `menu_warungs`
--
ALTER TABLE `menu_warungs`
  ADD PRIMARY KEY (`id_menuWarung`);

--
-- Indexes for table `pket_warungs`
--
ALTER TABLE `pket_warungs`
  ADD PRIMARY KEY (`id_katering`);

--
-- Indexes for table `pmeja_warungs`
--
ALTER TABLE `pmeja_warungs`
  ADD PRIMARY KEY (`id_pesan`);

--
-- Indexes for table `tariks`
--
ALTER TABLE `tariks`
  ADD PRIMARY KEY (`id_tr`);

--
-- Indexes for table `topups`
--
ALTER TABLE `topups`
  ADD PRIMARY KEY (`id_tp`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `users_qrs`
--
ALTER TABLE `users_qrs`
  ADD PRIMARY KEY (`id_qr`);

--
-- Indexes for table `warungs`
--
ALTER TABLE `warungs`
  ADD PRIMARY KEY (`id_warung`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `info_warungs`
--
ALTER TABLE `info_warungs`
  MODIFY `id_infoWarung` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=369;

--
-- AUTO_INCREMENT for table `menu_warungs`
--
ALTER TABLE `menu_warungs`
  MODIFY `id_menuWarung` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=305;

--
-- AUTO_INCREMENT for table `pket_warungs`
--
ALTER TABLE `pket_warungs`
  MODIFY `id_katering` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1265;

--
-- AUTO_INCREMENT for table `pmeja_warungs`
--
ALTER TABLE `pmeja_warungs`
  MODIFY `id_pesan` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=696193;

--
-- AUTO_INCREMENT for table `tariks`
--
ALTER TABLE `tariks`
  MODIFY `id_tr` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `topups`
--
ALTER TABLE `topups`
  MODIFY `id_tp` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1052;

--
-- AUTO_INCREMENT for table `users_qrs`
--
ALTER TABLE `users_qrs`
  MODIFY `id_qr` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `warungs`
--
ALTER TABLE `warungs`
  MODIFY `id_warung` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10978;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
